# 1.6.53
## Changelog:
- Themes Rework (Gradients, Color3)
- Fixed Label Colors
- Fixed `Tab:Select()`
- Fixed Dropdown Height
- Fixed `Window.BackgroundImageTransparency`
- Fixed Window Background Animation
- Fixed Input
- Fixed Section Center Text
- Fixed OpenButton on PC
- Fixed UI in studio (maybe)
- Added `IconSize` to `Window`
- Added `OpenButton` to `:CreateWindow()`
- Added Icons to `Dropdown`
- Added `IconOnly` to `OpenButton`
- Added Section box
- Added `:SetMax(number)` and `:SetMin(number)` to `Slider`